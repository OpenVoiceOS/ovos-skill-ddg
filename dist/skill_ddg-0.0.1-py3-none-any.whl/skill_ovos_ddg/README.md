# <img src='./res/icon/ddg.png' card_color='#de5833' width='50' height='50' style='vertical-align:bottom'/> DuckDuckGo
Use DuckDuckGo to answer questions

![](./ui/logo.png)


## About

Uses the [DuckDuckGo API](https://duckduckgo.com/api) to provide information. 

NOTE: this is meant a better alternative to the official duck duck go skill, it will be blacklisted

## Examples

* "when was stephen hawking born"
* "ask the duck about the big bang"
* "tell me more"
* "who is elon musk"
* "continue"
* "tell me more"


## Category
**Information**

## Tags
#duckduckgo
#query
#search-engine
#searchengine
